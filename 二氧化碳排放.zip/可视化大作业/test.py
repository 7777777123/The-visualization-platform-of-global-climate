import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np  

PLOT_CONFIG = {
    "font": {"family": "Arial", "size": 12},
    "title": {"font": {"size": 16, "weight": "bold"}},
    "legend": {"orientation": "h", "yanchor": "bottom", "y": -0.3},  
    "hovermode": "x unified"
}

DATA_PATHS = {
    "annual_emission": "C:/Users/LENOVO/Desktop/可视化大作业/annual-co2-emissions-per-country.csv",
    "per_capita_emission": "C:/Users/LENOVO/Desktop/可视化大作业/co-emissions-per-capita.csv",
    "emission_source": "C:/Users/LENOVO/Desktop/可视化大作业/co2-by-source.csv"
}

# -------------------------- 1. 时间序列图 --------------------------
def plot_emission_trend():
    df = pd.read_csv(DATA_PATHS["annual_emission"])
    core_entities = [
        "World", "China", "United States", "India", "Russia", 
        "Germany", "France", "United Kingdom", "Australia", "Brazil"
    ]
    available_2024 = df[df["Year"] == 2024]["Entity"].unique()
    core_entities = [entity for entity in core_entities if entity in available_2024]
    df_core = df[df["Entity"].isin(core_entities)].copy()
    df_core["Annual CO₂ emissions (Mt)"] = df_core["Annual CO₂ emissions"] / 1000000    
    fig = px.line(
        df_core,
        x="Year",
        y="Annual CO₂ emissions (Mt)",
        color="Entity",
        color_discrete_map={
            "China": "#e74c3c", "United States": "#3498db", "World": "#2c3e50",
            "India": "#f39c12", "Russia": "#9b59b6", "Others": "#95a5a6"
        },
        title="1970-2024年全球及主要国家CO₂排放量趋势",
        labels={"Annual CO₂ emissions (Mt)": "CO₂排放量（百万吨）", "Year": "年份"}
    )   
    for trace in fig.data:
        if trace.name in ["China", "United States", "World"]:
            trace.line.width = 3
        else:
            trace.line.width = 1.5
            trace.opacity = 0.7 
    fig.update_layout(**PLOT_CONFIG)
    fig.write_html("C:/Users/LENOVO/Desktop/可视化大作业/1_排放趋势时间序列图.html")
    print("时间序列图已保存：1_排放趋势时间序列图.html")
    return fig

# -------------------------- 2. 地理可视化 --------------------------
def plot_emission_geo():
    df = pd.read_csv(DATA_PATHS["annual_emission"])
    df_2024 = df[
        (df["Year"] == 2024) & 
        (df["Code"].notna()) &  
        (df["Code"] != "") &   
        (df["Code"].str.len() == 3) 
    ].copy()
    # 单位转换：吨 → 百万吨（统一单位）
    df_2024["Annual CO₂ emissions (Mt)"] = df_2024["Annual CO₂ emissions"] / 1000000
    df_2024["Annual CO₂ emissions (Mt)"] = df_2024["Annual CO₂ emissions (Mt)"].replace(0, 0.001)  
    df_2024["Emission_log"] = np.log10(df_2024["Annual CO₂ emissions (Mt)"])  
    fig = px.choropleth(
        df_2024,
        locations="Code",
        locationmode="ISO-3",
        color="Emission_log",  
        color_continuous_scale=px.colors.sequential.Bluered_r,  
        hover_name="Entity",
        hover_data={
            "Annual CO₂ emissions (Mt)": ":,.2f",  
            "Emission_log": False, 
            "Code": False,
            "Year": False
        },
        title="2024年全球各国CO₂排放量地理分布（含低排放国家）",
        labels={"Emission_log": "CO₂排放量（百万吨，对数刻度）"}  
    )
    fig.update_geos(
        showcoastlines=True, coastlinecolor="black", coastlinewidth=0.5,
        showcountries=True, countrycolor="black", countrywidth=0.3,
        showland=True, landcolor="#f5f5f5",
        showocean=True, oceancolor="#eaf2f8",
        showlakes=True, lakecolor="#eaf2f8",
        resolution=110,
        fitbounds="locations"
    )
    log_ticks = [-3, -2, -1, 0, 1, 2, 3, 4]  
    tick_text = [f"10^{tick} = {10**tick:.1f}" for tick in log_ticks]  
    fig.update_layout(
        **PLOT_CONFIG,
        coloraxis_colorbar={
            "title": "CO₂排放量（百万吨）",
            "tickvals": log_ticks,  
            "ticktext": tick_text,  
            "len": 0.8,
            "y": 0.5
        },
        height=800
    )
    fig.write_html("C:/Users/LENOVO/Desktop/可视化大作业/2_2024年排放地理分布图（全国家）.html")
    print(f"地理分布图已保存，共展示 {len(df_2024)} 个国家/地区")
    return fig

# -------------------------- 3. 柱状图：2024年全球多国家人均CO₂排放量对比 --------------------------
def plot_per_capita_bar():
    df = pd.read_csv(DATA_PATHS["per_capita_emission"])
    df_2024 = df[
        (df["Year"] == 2024) & 
        (df["Code"].notna()) & 
        (df["Code"] != "") & 
        (df["Annual CO₂ emissions (per capita)"] >= 0.1)
    ].copy()
    df_2024 = df_2024.sort_values("Annual CO₂ emissions (per capita)", ascending=False)
    def get_income_group(per_capita):
        if per_capita >= 10:
            return "高收入国家（≥10吨/人）"
        elif per_capita >= 3:
            return "中高收入国家（3-10吨/人）"
        elif per_capita >= 1:
            return "中低收入国家（1-3吨/人）"
        else:
            return "低收入国家（0.1-1吨/人）"
    df_2024["收入分组"] = df_2024["Annual CO₂ emissions (per capita)"].apply(get_income_group)
    fig = px.bar(
        df_2024,
        x="Entity",
        y="Annual CO₂ emissions (per capita)",
        color="收入分组",
        color_discrete_map={
            "高收入国家（≥10吨/人）": "#e74c3c", 
            "中高收入国家（3-10吨/人）": "#3498db", 
            "中低收入国家（1-3吨/人）": "#f39c12", 
            "低收入国家（0.1-1吨/人）": "#2ecc71"
        },
        title="2024年全球主要国家人均CO₂排放量对比（筛选后：人均≥0.1吨/人）",
        labels={"Annual CO₂ emissions (per capita)": "人均CO₂排放量（吨/人）", "Entity": "国家/地区"}
    )
    fig.update_traces(
        text=df_2024["Annual CO₂ emissions (per capita)"].round(2),
        textposition="outside",
        textfont={"size": 8}
    )
    fig.update_layout(
        **PLOT_CONFIG,
        xaxis_tickangle=-45,
        xaxis={"title": "国家/地区", "tickfont": {"size": 9}},
        height=800
    )
    fig.write_html("C:/Users/LENOVO/Desktop/可视化大作业/3_2024年多国家人均排放柱状图.html")
    print(f"多国家人均排放柱状图已保存，共展示 {len(df_2024)} 个国家/地区")
    return fig

# -------------------------- 4. 堆叠柱状图 --------------------------
def plot_emission_structure():
    df = pd.read_csv(DATA_PATHS["emission_source"])
    target_entities = ["China", "World"]
    key_years = [2000, 2005, 2010, 2015, 2020, 2024]
    df_target = df[(df["Entity"].isin(target_entities)) & (df["Year"].isin(key_years))].copy()
    emission_sources = [
        "Annual CO₂ emissions from other industry",
        "Annual CO₂ emissions from flaring",
        "Annual CO₂ emissions from cement",
        "Annual CO₂ emissions from gas",
        "Annual CO₂ emissions from oil",
        "Annual CO₂ emissions from coal"
    ]
    source_rename = {
        "Annual CO₂ emissions from other industry": "其他工业",
        "Annual CO₂ emissions from flaring": "燃烧",
        "Annual CO₂ emissions from cement": "水泥",
        "Annual CO₂ emissions from gas": "天然气",
        "Annual CO₂ emissions from oil": "石油",
        "Annual CO₂ emissions from coal": "煤炭"
    }
    for col in emission_sources:
        if col in df_target.columns:
            df_target[source_rename[col]] = df_target[col] / 1000000
    fig = make_subplots(rows=1, cols=2, subplot_titles=("中国CO₂排放结构", "世界CO₂排放结构"), shared_yaxes=True)
    source_colors = {
        "煤炭": "#e74c3c", "石油": "#f39c12", "天然气": "#3498db",
        "水泥": "#9b59b6", "燃烧": "#e67e22", "其他工业": "#95a5a6"
    }
    for entity, col in zip(target_entities, [1, 2]):
        df_entity = df_target[df_target["Entity"] == entity]
        for source in source_rename.values():
            if source in df_entity.columns:
                fig.add_trace(
                    go.Bar(x=df_entity["Year"], y=df_entity[source], name=source, marker_color=source_colors[source], hoverinfo="x+y+name"),
                    row=1, col=col
                )
    
    fig.update_layout(title_text="2000-2024年中国与世界CO₂排放结构对比（按来源）", yaxis_title="CO₂排放量（百万吨）", **PLOT_CONFIG)
    fig.write_html("C:/Users/LENOVO/Desktop/可视化大作业/4_排放结构堆叠柱状图.html")
    print("排放结构堆叠图已保存：4_排放结构堆叠柱状图.html")
    return fig

# -------------------------- 主程序 --------------------------
if __name__ == "__main__":
    try:
        plot_emission_trend()
        geo_fig = plot_emission_geo()  
        plot_per_capita_bar()
        plot_emission_structure()
        df_geo = pd.read_csv(DATA_PATHS["annual_emission"])
        df_geo_2024 = df_geo[
            (df_geo["Year"] == 2024) & 
            (df_geo["Code"].notna()) & 
            (df_geo["Code"] != "") & 
            (df_geo["Code"].str.len() == 3)
        ]
        df_per_capita = pd.read_csv(DATA_PATHS["per_capita_emission"])
        df_per_capita_2024 = df_per_capita[
            (df_per_capita["Year"] == 2024) & 
            (df_per_capita["Code"].notna()) & 
            (df_per_capita["Code"] != "") & 
            (df_per_capita["Annual CO₂ emissions (per capita)"] >= 0.1)
        ]
        print(f"\n所有图表生成完成！")
        print(f"地理分布图共展示 {len(df_geo_2024)} 个国家/地区")
        print(f"人均排放图共展示 {len(df_per_capita_2024)} 个国家/地区")
    except FileNotFoundError as e:
        print(f"\n路径错误：{str(e)}，请检查文件是否在指定目录")
    except Exception as e:
        print(f"\n执行错误：{str(e)}")